'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  Search, 
  Filter, 
  TrendingUp, 
  DollarSign, 
  Users, 
  Target,
  Eye,
  Heart,
  MessageSquare,
  Calendar,
  Star,
  Brain,
  BarChart3,
  PieChart,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle,
  Clock,
  AlertCircle,
  Lightbulb
} from 'lucide-react'

interface Project {
  id: string
  title: string
  description: string
  category: string
  stage: string
  fundingGoal: number
  currentFunding: number
  minInvestment: number
  maxInvestment?: number
  equity?: number
  valuation?: number
  status: string
  entrepreneur: string
  entrepreneurAvatar: string
  createdAt: string
  views: number
  investors: number
  aiScore?: number
  aiReasons?: string[]
  isWatchlisted?: boolean
}

export default function InvestorDashboard() {
  const [projects, setProjects] = useState<Project[]>([])
  const [filteredProjects, setFilteredProjects] = useState<Project[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [selectedStage, setSelectedStage] = useState('all')
  const [sortBy, setSortBy] = useState('ai-score')
  const [watchlist, setWatchlist] = useState<string[]>([])

  useEffect(() => {
    // Mock data for demonstration
    const mockProjects: Project[] = [
      {
        id: '1',
        title: 'AI-Powered Healthcare Platform',
        description: 'Revolutionary AI platform for personalized healthcare recommendations and early disease detection using machine learning algorithms.',
        category: 'Healthcare',
        stage: 'MVP',
        fundingGoal: 500000,
        currentFunding: 325000,
        minInvestment: 10000,
        maxInvestment: 100000,
        equity: 15,
        valuation: 3333333,
        status: 'approved',
        entrepreneur: 'Sarah Chen',
        entrepreneurAvatar: 'SC',
        createdAt: '2024-01-15',
        views: 1247,
        investors: 23,
        aiScore: 92,
        aiReasons: ['Strong market potential', 'Experienced team', 'Proprietary technology'],
        isWatchlisted: false
      },
      {
        id: '2',
        title: 'Sustainable Energy Storage Solution',
        description: 'Next-generation battery technology using sustainable materials for grid-scale energy storage with 3x longer lifespan.',
        category: 'Energy',
        stage: 'Prototype',
        fundingGoal: 750000,
        currentFunding: 180000,
        minInvestment: 25000,
        maxInvestment: 150000,
        equity: 12,
        valuation: 6250000,
        status: 'approved',
        entrepreneur: 'Michael Rodriguez',
        entrepreneurAvatar: 'MR',
        createdAt: '2024-02-01',
        views: 892,
        investors: 15,
        aiScore: 88,
        aiReasons: ['Green technology trend', 'Scalable business model', 'Strong IP portfolio'],
        isWatchlisted: true
      },
      {
        id: '3',
        title: 'EdTech Virtual Reality Platform',
        description: 'Immersive VR platform for interactive education and professional training with gamification elements.',
        category: 'Education',
        stage: 'Idea',
        fundingGoal: 300000,
        currentFunding: 0,
        minInvestment: 5000,
        maxInvestment: 50000,
        equity: 10,
        valuation: 3000000,
        status: 'approved',
        entrepreneur: 'Emily Johnson',
        entrepreneurAvatar: 'EJ',
        createdAt: '2024-02-20',
        views: 156,
        investors: 3,
        aiScore: 75,
        aiReasons: ['Growing EdTech market', 'Innovative approach', 'Early stage opportunity'],
        isWatchlisted: false
      },
      {
        id: '4',
        title: 'Blockchain Supply Chain Solution',
        description: 'Transparent and secure supply chain management using blockchain technology for real-time tracking.',
        category: 'Technology',
        stage: 'MVP',
        fundingGoal: 400000,
        currentFunding: 280000,
        minInvestment: 15000,
        maxInvestment: 80000,
        equity: 8,
        valuation: 5000000,
        status: 'approved',
        entrepreneur: 'David Kim',
        entrepreneurAvatar: 'DK',
        createdAt: '2024-01-28',
        views: 743,
        investors: 18,
        aiScore: 85,
        aiReasons: ['Enterprise demand', 'B2B model', 'Experienced advisors'],
        isWatchlisted: false
      },
      {
        id: '5',
        title: 'Precision Agriculture Drone System',
        description: 'AI-powered drones for crop monitoring and precision agriculture with automated analytics.',
        category: 'Agriculture',
        stage: 'Prototype',
        fundingGoal: 600000,
        currentFunding: 95000,
        minInvestment: 20000,
        maxInvestment: 120000,
        equity: 14,
        valuation: 4285714,
        status: 'approved',
        entrepreneur: 'Lisa Wang',
        entrepreneurAvatar: 'LW',
        createdAt: '2024-02-10',
        views: 521,
        investors: 9,
        aiScore: 82,
        aiReasons: ['Agriculture tech trend', 'Clear ROI model', 'Pilot programs successful'],
        isWatchlisted: true
      }
    ]
    setProjects(mockProjects)
    setFilteredProjects(mockProjects)
  }, [])

  useEffect(() => {
    let filtered = projects

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(project =>
        project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        project.category.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(project => project.category === selectedCategory)
    }

    // Filter by stage
    if (selectedStage !== 'all') {
      filtered = filtered.filter(project => project.stage === selectedStage)
    }

    // Sort projects
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'ai-score':
          return (b.aiScore || 0) - (a.aiScore || 0)
        case 'funding-progress':
          return (b.currentFunding / b.fundingGoal) - (a.currentFunding / a.fundingGoal)
        case 'newest':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        case 'valuation':
          return (b.valuation || 0) - (a.valuation || 0)
        default:
          return 0
      }
    })

    setFilteredProjects(filtered)
  }, [projects, searchTerm, selectedCategory, selectedStage, sortBy])

  const toggleWatchlist = (projectId: string) => {
    if (watchlist.includes(projectId)) {
      setWatchlist(watchlist.filter(id => id !== projectId))
    } else {
      setWatchlist([...watchlist, projectId])
    }
  }

  const getAIScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600 bg-green-100'
    if (score >= 80) return 'text-blue-600 bg-blue-100'
    if (score >= 70) return 'text-yellow-600 bg-yellow-100'
    return 'text-red-600 bg-red-100'
  }

  const totalInvestments = 1250000
  const portfolioValue = 2850000
  const activeInvestments = 8
  const totalReturns = 28.5

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold">Investor Dashboard</h1>
            <p className="text-slate-600 dark:text-slate-400">Discover and invest in promising ventures</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              Advanced Filters
            </Button>
            <Button>
              <Brain className="h-4 w-4 mr-2" />
              AI Recommendations
            </Button>
          </div>
        </div>

        {/* Portfolio Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Total Invested</p>
                  <p className="text-2xl font-bold">${(totalInvestments / 1000000).toFixed(1)}M</p>
                  <p className="text-xs text-green-600 flex items-center">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    +12.5% this month
                  </p>
                </div>
                <div className="h-8 w-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <DollarSign className="h-4 w-4 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Portfolio Value</p>
                  <p className="text-2xl font-bold">${(portfolioValue / 1000000).toFixed(1)}M</p>
                  <p className="text-xs text-green-600 flex items-center">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    +{totalReturns}% returns
                  </p>
                </div>
                <div className="h-8 w-8 bg-green-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Active Investments</p>
                  <p className="text-2xl font-bold">{activeInvestments}</p>
                  <p className="text-xs text-slate-600">3 performing well</p>
                </div>
                <div className="h-8 w-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <Target className="h-4 w-4 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Watchlist</p>
                  <p className="text-2xl font-bold">{watchlist.length}</p>
                  <p className="text-xs text-slate-600">5 new matches</p>
                </div>
                <div className="h-8 w-8 bg-orange-100 rounded-full flex items-center justify-center">
                  <Heart className="h-4 w-4 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="discover" className="space-y-6">
          <TabsList>
            <TabsTrigger value="discover">Discover Projects</TabsTrigger>
            <TabsTrigger value="portfolio">My Portfolio</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="messages">Messages</TabsTrigger>
          </TabsList>

          <TabsContent value="discover" className="space-y-6">
            {/* Search and Filters */}
            <Card>
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <Input
                      placeholder="Search projects..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="technology">Technology</SelectItem>
                      <SelectItem value="healthcare">Healthcare</SelectItem>
                      <SelectItem value="education">Education</SelectItem>
                      <SelectItem value="energy">Energy</SelectItem>
                      <SelectItem value="agriculture">Agriculture</SelectItem>
                      <SelectItem value="finance">Finance</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={selectedStage} onValueChange={setSelectedStage}>
                    <SelectTrigger>
                      <SelectValue placeholder="Stage" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Stages</SelectItem>
                      <SelectItem value="idea">Idea</SelectItem>
                      <SelectItem value="prototype">Prototype</SelectItem>
                      <SelectItem value="mvp">MVP</SelectItem>
                      <SelectItem value="growth">Growth</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ai-score">AI Score</SelectItem>
                      <SelectItem value="funding-progress">Funding Progress</SelectItem>
                      <SelectItem value="newest">Newest</SelectItem>
                      <SelectItem value="valuation">Valuation</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Projects Grid */}
            <div className="grid gap-6">
              {filteredProjects.map((project) => (
                <Card key={project.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <CardTitle className="text-xl">{project.title}</CardTitle>
                          {project.aiScore && (
                            <Badge className={getAIScoreColor(project.aiScore)}>
                              <Brain className="h-3 w-3 mr-1" />
                              AI Score: {project.aiScore}
                            </Badge>
                          )}
                          <Badge variant="outline">{project.category}</Badge>
                        </div>
                        <CardDescription className="text-base mb-3">
                          {project.description}
                        </CardDescription>
                        <div className="flex items-center gap-4 text-sm text-slate-600">
                          <span className="flex items-center gap-1">
                            <Target className="h-3 w-3" />
                            {project.stage}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {project.createdAt}
                          </span>
                          <span className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            {project.investors} investors
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleWatchlist(project.id)}
                          className={watchlist.includes(project.id) ? 'text-red-600' : ''}
                        >
                          <Heart className={`h-4 w-4 ${watchlist.includes(project.id) ? 'fill-current' : ''}`} />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span>Funding Progress</span>
                          <span className="font-medium">
                            ${project.currentFunding.toLocaleString()} / ${project.fundingGoal.toLocaleString()}
                          </span>
                        </div>
                        <Progress value={(project.currentFunding / project.fundingGoal) * 100} className="h-2 mb-4" />
                        
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-slate-600">Min Investment</span>
                            <span className="font-medium">${project.minInvestment.toLocaleString()}</span>
                          </div>
                          {project.maxInvestment && (
                            <div className="flex justify-between">
                              <span className="text-slate-600">Max Investment</span>
                              <span className="font-medium">${project.maxInvestment.toLocaleString()}</span>
                            </div>
                          )}
                          {project.equity && (
                            <div className="flex justify-between">
                              <span className="text-slate-600">Equity</span>
                              <span className="font-medium">{project.equity}%</span>
                            </div>
                          )}
                          {project.valuation && (
                            <div className="flex justify-between">
                              <span className="text-slate-600">Valuation</span>
                              <span className="font-medium">${(project.valuation / 1000000).toFixed(1)}M</span>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex items-center gap-3 mb-3">
                          <Avatar>
                            <AvatarFallback>{project.entrepreneurAvatar}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{project.entrepreneur}</p>
                            <p className="text-sm text-slate-600">Entrepreneur</p>
                          </div>
                        </div>
                        
                        {project.aiReasons && (
                          <div>
                            <p className="text-sm font-medium mb-2">AI Insights:</p>
                            <div className="space-y-1">
                              {project.aiReasons.slice(0, 2).map((reason, index) => (
                                <div key={index} className="flex items-center gap-2 text-xs text-slate-600">
                                  <Lightbulb className="h-3 w-3 text-yellow-500" />
                                  {reason}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                      
                      <div className="flex flex-col justify-between">
                        <div className="grid grid-cols-2 gap-4 text-center mb-4">
                          <div>
                            <p className="text-lg font-bold">{project.views}</p>
                            <p className="text-xs text-slate-600">Views</p>
                          </div>
                          <div>
                            <p className="text-lg font-bold">{project.investors}</p>
                            <p className="text-xs text-slate-600">Investors</p>
                          </div>
                        </div>
                        
                        <div className="flex gap-2">
                          <Button size="sm" className="flex-1">
                            Invest Now
                          </Button>
                          <Button variant="outline" size="sm">
                            <MessageSquare className="h-4 w-4 mr-2" />
                            Contact
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="portfolio" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Portfolio Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-center">
                      <PieChart className="h-12 w-12 mx-auto mb-4 text-slate-400" />
                      <p className="text-slate-600 dark:text-slate-400">
                        Portfolio performance chart
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Investment Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { name: 'AI Healthcare', value: 325000, return: 15.2 },
                      { name: 'Energy Storage', value: 250000, return: 8.7 },
                      { name: 'EdTech VR', value: 150000, return: -2.3 },
                      { name: 'Blockchain Supply', value: 200000, return: 22.1 },
                      { name: 'AgriTech Drones', value: 175000, return: 12.8 }
                    ].map((investment, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-sm">{investment.name}</p>
                          <p className="text-xs text-slate-600">${investment.value.toLocaleString()}</p>
                        </div>
                        <Badge 
                          variant={investment.return > 0 ? "default" : "destructive"}
                          className="text-xs"
                        >
                          {investment.return > 0 ? '+' : ''}{investment.return}%
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    Investment Trends
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-center">
                      <BarChart3 className="h-12 w-12 mx-auto mb-4 text-slate-400" />
                      <p className="text-slate-600 dark:text-slate-400">
                        Investment trends over time
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Market Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">Healthcare Tech</h4>
                        <Badge variant="secondary">Hot</Badge>
                      </div>
                      <p className="text-sm text-slate-600">32% growth in Q4, AI-driven diagnostics leading</p>
                    </div>
                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">Clean Energy</h4>
                        <Badge variant="secondary">Rising</Badge>
                      </div>
                      <p className="text-sm text-slate-600">28% increase in funding, battery tech breakthroughs</p>
                    </div>
                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">EdTech</h4>
                        <Badge variant="outline">Stable</Badge>
                      </div>
                      <p className="text-sm text-slate-600">15% steady growth, VR/AR adoption increasing</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="messages" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Entrepreneur Messages</CardTitle>
                <CardDescription>Communicate with project founders</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <MessageSquare className="h-12 w-12 mx-auto mb-4 text-slate-400" />
                  <p className="text-slate-600">No new messages</p>
                  <p className="text-sm text-slate-500">Reach out to entrepreneurs you're interested in</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}