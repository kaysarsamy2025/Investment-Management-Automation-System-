'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  Plus, 
  Rocket, 
  DollarSign, 
  Users, 
  TrendingUp,
  FileText,
  MessageSquare,
  Calendar,
  Target,
  Eye,
  Edit,
  MoreHorizontal,
  CheckCircle,
  Clock,
  AlertCircle,
  BarChart3,
  Lightbulb
} from 'lucide-react'

interface Project {
  id: string
  title: string
  description: string
  category: string
  stage: string
  fundingGoal: number
  currentFunding: number
  minInvestment: number
  maxInvestment?: number
  equity?: number
  status: string
  createdAt: string
  views: number
  investors: number
  messages: number
}

export default function EntrepreneurDashboard() {
  const [projects, setProjects] = useState<Project[]>([])
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [newProject, setNewProject] = useState({
    title: '',
    description: '',
    category: '',
    stage: '',
    fundingGoal: '',
    minInvestment: '',
    maxInvestment: '',
    equity: ''
  })

  useEffect(() => {
    // Mock data for demonstration
    const mockProjects: Project[] = [
      {
        id: '1',
        title: 'AI-Powered Healthcare Platform',
        description: 'Revolutionary AI platform for personalized healthcare recommendations and early disease detection.',
        category: 'Healthcare',
        stage: 'MVP',
        fundingGoal: 500000,
        currentFunding: 325000,
        minInvestment: 10000,
        maxInvestment: 100000,
        equity: 15,
        status: 'approved',
        createdAt: '2024-01-15',
        views: 1247,
        investors: 23,
        messages: 45
      },
      {
        id: '2',
        title: 'Sustainable Energy Storage Solution',
        description: 'Next-generation battery technology using sustainable materials for grid-scale energy storage.',
        category: 'Energy',
        stage: 'Prototype',
        fundingGoal: 750000,
        currentFunding: 180000,
        minInvestment: 25000,
        maxInvestment: 150000,
        equity: 12,
        status: 'approved',
        createdAt: '2024-02-01',
        views: 892,
        investors: 15,
        messages: 28
      },
      {
        id: '3',
        title: 'EdTech Virtual Reality Platform',
        description: 'Immersive VR platform for interactive education and professional training.',
        category: 'Education',
        stage: 'Idea',
        fundingGoal: 300000,
        currentFunding: 0,
        minInvestment: 5000,
        maxInvestment: 50000,
        equity: 10,
        status: 'draft',
        createdAt: '2024-02-20',
        views: 156,
        investors: 3,
        messages: 8
      }
    ]
    setProjects(mockProjects)
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'submitted':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'draft':
        return 'bg-gray-100 text-gray-800 border-gray-200'
      case 'funded':
        return 'bg-purple-100 text-purple-800 border-purple-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case 'submitted':
        return <Clock className="h-4 w-4 text-blue-600" />
      case 'draft':
        return <Edit className="h-4 w-4 text-gray-600" />
      case 'funded':
        return <DollarSign className="h-4 w-4 text-purple-600" />
      default:
        return <AlertCircle className="h-4 w-4 text-gray-600" />
    }
  }

  const totalFunding = projects.reduce((sum, project) => sum + project.currentFunding, 0)
  const totalGoal = projects.reduce((sum, project) => sum + project.fundingGoal, 0)
  const totalViews = projects.reduce((sum, project) => sum + project.views, 0)
  const totalInvestors = projects.reduce((sum, project) => sum + project.investors, 0)

  const handleCreateProject = () => {
    if (newProject.title && newProject.description) {
      const project: Project = {
        id: Date.now().toString(),
        title: newProject.title,
        description: newProject.description,
        category: newProject.category,
        stage: newProject.stage,
        fundingGoal: parseFloat(newProject.fundingGoal),
        currentFunding: 0,
        minInvestment: parseFloat(newProject.minInvestment),
        maxInvestment: newProject.maxInvestment ? parseFloat(newProject.maxInvestment) : undefined,
        equity: newProject.equity ? parseFloat(newProject.equity) : undefined,
        status: 'draft',
        createdAt: new Date().toISOString().split('T')[0],
        views: 0,
        investors: 0,
        messages: 0
      }
      setProjects([...projects, project])
      setNewProject({
        title: '',
        description: '',
        category: '',
        stage: '',
        fundingGoal: '',
        minInvestment: '',
        maxInvestment: '',
        equity: ''
      })
      setIsCreateDialogOpen(false)
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold">Entrepreneur Dashboard</h1>
            <p className="text-slate-600 dark:text-slate-400">Manage your projects and track investment progress</p>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                New Project
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Project</DialogTitle>
                <DialogDescription>
                  Submit your project for potential investment
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="text-sm font-medium">Project Title</label>
                  <Input
                    value={newProject.title}
                    onChange={(e) => setNewProject({...newProject, title: e.target.value})}
                    placeholder="Enter project title"
                  />
                </div>
                <div className="col-span-2">
                  <label className="text-sm font-medium">Description</label>
                  <Textarea
                    value={newProject.description}
                    onChange={(e) => setNewProject({...newProject, description: e.target.value})}
                    placeholder="Describe your project"
                    rows={4}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Category</label>
                  <Select value={newProject.category} onValueChange={(value) => setNewProject({...newProject, category: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="technology">Technology</SelectItem>
                      <SelectItem value="healthcare">Healthcare</SelectItem>
                      <SelectItem value="finance">Finance</SelectItem>
                      <SelectItem value="education">Education</SelectItem>
                      <SelectItem value="energy">Energy</SelectItem>
                      <SelectItem value="agriculture">Agriculture</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium">Stage</label>
                  <Select value={newProject.stage} onValueChange={(value) => setNewProject({...newProject, stage: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select stage" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="idea">Idea</SelectItem>
                      <SelectItem value="prototype">Prototype</SelectItem>
                      <SelectItem value="mvp">MVP</SelectItem>
                      <SelectItem value="growth">Growth</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium">Funding Goal ($)</label>
                  <Input
                    type="number"
                    value={newProject.fundingGoal}
                    onChange={(e) => setNewProject({...newProject, fundingGoal: e.target.value})}
                    placeholder="500000"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Min Investment ($)</label>
                  <Input
                    type="number"
                    value={newProject.minInvestment}
                    onChange={(e) => setNewProject({...newProject, minInvestment: e.target.value})}
                    placeholder="10000"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Max Investment ($)</label>
                  <Input
                    type="number"
                    value={newProject.maxInvestment}
                    onChange={(e) => setNewProject({...newProject, maxInvestment: e.target.value})}
                    placeholder="100000"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Equity Offered (%)</label>
                  <Input
                    type="number"
                    value={newProject.equity}
                    onChange={(e) => setNewProject({...newProject, equity: e.target.value})}
                    placeholder="15"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 mt-6">
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateProject}>
                  Create Project
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Total Projects</p>
                  <p className="text-2xl font-bold">{projects.length}</p>
                </div>
                <div className="h-8 w-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <Rocket className="h-4 w-4 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Total Raised</p>
                  <p className="text-2xl font-bold">${(totalFunding / 1000000).toFixed(1)}M</p>
                </div>
                <div className="h-8 w-8 bg-green-100 rounded-full flex items-center justify-center">
                  <DollarSign className="h-4 w-4 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Total Investors</p>
                  <p className="text-2xl font-bold">{totalInvestors}</p>
                </div>
                <div className="h-8 w-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <Users className="h-4 w-4 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Project Views</p>
                  <p className="text-2xl font-bold">{totalViews.toLocaleString()}</p>
                </div>
                <div className="h-8 w-8 bg-orange-100 rounded-full flex items-center justify-center">
                  <Eye className="h-4 w-4 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="projects" className="space-y-6">
          <TabsList>
            <TabsTrigger value="projects">My Projects</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="messages">Messages</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
          </TabsList>

          <TabsContent value="projects" className="space-y-6">
            <div className="grid gap-6">
              {projects.map((project) => (
                <Card key={project.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <CardTitle className="text-xl">{project.title}</CardTitle>
                          <Badge className={getStatusColor(project.status)}>
                            <div className="flex items-center gap-1">
                              {getStatusIcon(project.status)}
                              {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
                            </div>
                          </Badge>
                        </div>
                        <CardDescription className="text-base">
                          {project.description}
                        </CardDescription>
                        <div className="flex items-center gap-4 mt-3 text-sm text-slate-600">
                          <span className="flex items-center gap-1">
                            <Target className="h-3 w-3" />
                            {project.category}
                          </span>
                          <span className="flex items-center gap-1">
                            <Rocket className="h-3 w-3" />
                            {project.stage}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {project.createdAt}
                          </span>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span>Funding Progress</span>
                          <span className="font-medium">
                            ${project.currentFunding.toLocaleString()} / ${project.fundingGoal.toLocaleString()}
                          </span>
                        </div>
                        <Progress value={(project.currentFunding / project.fundingGoal) * 100} className="h-2 mb-4" />
                        
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-slate-600">Min Investment</span>
                            <p className="font-medium">${project.minInvestment.toLocaleString()}</p>
                          </div>
                          {project.maxInvestment && (
                            <div>
                              <span className="text-slate-600">Max Investment</span>
                              <p className="font-medium">${project.maxInvestment.toLocaleString()}</p>
                            </div>
                          )}
                          {project.equity && (
                            <div>
                              <span className="text-slate-600">Equity Offered</span>
                              <p className="font-medium">{project.equity}%</p>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div>
                        <div className="grid grid-cols-3 gap-4 text-center">
                          <div>
                            <div className="flex items-center justify-center mb-1">
                              <Eye className="h-4 w-4 text-blue-600" />
                            </div>
                            <p className="text-lg font-bold">{project.views}</p>
                            <p className="text-xs text-slate-600">Views</p>
                          </div>
                          <div>
                            <div className="flex items-center justify-center mb-1">
                              <Users className="h-4 w-4 text-green-600" />
                            </div>
                            <p className="text-lg font-bold">{project.investors}</p>
                            <p className="text-xs text-slate-600">Investors</p>
                          </div>
                          <div>
                            <div className="flex items-center justify-center mb-1">
                              <MessageSquare className="h-4 w-4 text-purple-600" />
                            </div>
                            <p className="text-lg font-bold">{project.messages}</p>
                            <p className="text-xs text-slate-600">Messages</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex gap-2 mt-6">
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4 mr-2" />
                        View Details
                      </Button>
                      <Button variant="outline" size="sm">
                        <Edit className="h-4 w-4 mr-2" />
                        Edit Project
                      </Button>
                      <Button variant="outline" size="sm">
                        <FileText className="h-4 w-4 mr-2" />
                        Documents
                      </Button>
                      <Button variant="outline" size="sm">
                        <BarChart3 className="h-4 w-4 mr-2" />
                        Analytics
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Funding Overview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-center">
                      <BarChart3 className="h-12 w-12 mx-auto mb-4 text-slate-400" />
                      <p className="text-slate-600 dark:text-slate-400">
                        Funding progress chart
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Investor Engagement
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {projects.map((project) => (
                      <div key={project.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-sm">{project.title}</p>
                          <p className="text-xs text-slate-600">{project.investors} investors</p>
                        </div>
                        <Badge variant="secondary">{project.views} views</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="messages" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Investor Messages</CardTitle>
                <CardDescription>Communicate with potential investors</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <MessageSquare className="h-12 w-12 mx-auto mb-4 text-slate-400" />
                  <p className="text-slate-600">No messages yet</p>
                  <p className="text-sm text-slate-500">Investors will reach out when they're interested in your projects</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="resources" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5" />
                    Entrepreneur Resources
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 border rounded-lg">
                      <h4 className="font-medium">Pitch Deck Template</h4>
                      <p className="text-sm text-slate-600">Professional template for your presentations</p>
                    </div>
                    <div className="p-3 border rounded-lg">
                      <h4 className="font-medium">Investment Guide</h4>
                      <p className="text-sm text-slate-600">Complete guide to securing funding</p>
                    </div>
                    <div className="p-3 border rounded-lg">
                      <h4 className="font-medium">Due Diligence Checklist</h4>
                      <p className="text-sm text-slate-600">Prepare for investor due diligence</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Legal Documents
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 border rounded-lg">
                      <h4 className="font-medium">Term Sheet Template</h4>
                      <p className="text-sm text-slate-600">Standard term sheet for investments</p>
                    </div>
                    <div className="p-3 border rounded-lg">
                      <h4 className="font-medium">Shareholder Agreement</h4>
                      <p className="text-sm text-slate-600">Template for shareholder agreements</p>
                    </div>
                    <div className="p-3 border rounded-lg">
                      <h4 className="font-medium">IP Protection Guide</h4>
                      <p className="text-sm text-slate-600">Protect your intellectual property</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}