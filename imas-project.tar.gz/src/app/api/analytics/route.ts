import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const period = searchParams.get('period') || '7d'

    // Mock analytics data
    const analyticsData = {
      overview: {
        totalRevenue: period === '7d' ? 48574 : period === '30d' ? 185474 : 485474,
        activeUsers: period === '7d' ? 12847 : period === '30d' ? 42847 : 128847,
        totalOrders: period === '7d' ? 3421 : period === '30d' ? 13421 : 34421,
        conversionRate: period === '7d' ? 3.2 : period === '30d' ? 3.8 : 4.1
      },
      revenue: {
        current: period === '7d' ? 48574 : period === '30d' ? 185474 : 485474,
        previous: period === '7d' ? 43210 : period === '30d' ? 165210 : 432210,
        change: period === '7d' ? 12.5 : period === '30d' ? 12.3 : 12.4
      },
      users: {
        current: period === '7d' ? 12847 : period === '30d' ? 42847 : 128847,
        previous: period === '7d' ? 11876 : period === '30d' ? 39621 : 118876,
        change: period === '7d' ? 8.2 : period === '30d' ? 8.1 : 8.4
      },
      orders: {
        current: period === '7d' ? 3421 : period === '30d' ? 13421 : 34421,
        previous: period === '7d' ? 3504 : period === '30d' ? 13754 : 35044,
        change: period === '7d' ? -2.4 : period === '30d' ? -2.4 : -1.8
      },
      trafficSources: [
        { source: "Direct", visitors: 3421, percentage: 45 },
        { source: "Organic Search", visitors: 2156, percentage: 28 },
        { source: "Social Media", visitors: 1284, percentage: 17 },
        { source: "Referral", visitors: 762, percentage: 10 }
      ],
      userEngagement: [
        { metric: "Page Views", value: "45.2K", change: "+12%" },
        { metric: "Avg. Session Duration", value: "3m 24s", change: "+8%" },
        { metric: "Bounce Rate", value: "42%", change: "-5%" },
        { metric: "Pages per Session", value: "3.2", change: "+15%" }
      ],
      topProducts: [
        { name: "Premium Plan", sales: 342, revenue: "$34,200" },
        { name: "Basic Plan", sales: 256, revenue: "$12,800" },
        { name: "Enterprise Plan", sales: 89, revenue: "$26,700" },
        { name: "Starter Plan", sales: 178, revenue: "$8,900" }
      ]
    }

    return NextResponse.json({
      success: true,
      data: analyticsData,
      period
    })
  } catch (error) {
    console.error('Error fetching analytics:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch analytics data' },
      { status: 500 }
    )
  }
}