import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const stage = searchParams.get('stage')
    const search = searchParams.get('search')
    const sortBy = searchParams.get('sortBy') || 'ai-score'

    // Mock projects data
    const mockProjects = [
      {
        id: '1',
        title: 'AI-Powered Healthcare Platform',
        description: 'Revolutionary AI platform for personalized healthcare recommendations and early disease detection using machine learning algorithms.',
        category: 'Healthcare',
        stage: 'MVP',
        fundingGoal: 500000,
        currentFunding: 325000,
        minInvestment: 10000,
        maxInvestment: 100000,
        equity: 15,
        valuation: 3333333,
        status: 'approved',
        entrepreneur: 'Sarah Chen',
        entrepreneurAvatar: 'SC',
        createdAt: '2024-01-15',
        views: 1247,
        investors: 23,
        aiScore: 92,
        aiReasons: ['Strong market potential', 'Experienced team', 'Proprietary technology']
      },
      {
        id: '2',
        title: 'Sustainable Energy Storage Solution',
        description: 'Next-generation battery technology using sustainable materials for grid-scale energy storage with 3x longer lifespan.',
        category: 'Energy',
        stage: 'Prototype',
        fundingGoal: 750000,
        currentFunding: 180000,
        minInvestment: 25000,
        maxInvestment: 150000,
        equity: 12,
        valuation: 6250000,
        status: 'approved',
        entrepreneur: 'Michael Rodriguez',
        entrepreneurAvatar: 'MR',
        createdAt: '2024-02-01',
        views: 892,
        investors: 15,
        aiScore: 88,
        aiReasons: ['Green technology trend', 'Scalable business model', 'Strong IP portfolio']
      },
      {
        id: '3',
        title: 'EdTech Virtual Reality Platform',
        description: 'Immersive VR platform for interactive education and professional training with gamification elements.',
        category: 'Education',
        stage: 'Idea',
        fundingGoal: 300000,
        currentFunding: 0,
        minInvestment: 5000,
        maxInvestment: 50000,
        equity: 10,
        valuation: 3000000,
        status: 'approved',
        entrepreneur: 'Emily Johnson',
        entrepreneurAvatar: 'EJ',
        createdAt: '2024-02-20',
        views: 156,
        investors: 3,
        aiScore: 75,
        aiReasons: ['Growing EdTech market', 'Innovative approach', 'Early stage opportunity']
      }
    ]

    let filteredProjects = mockProjects

    // Apply filters
    if (category && category !== 'all') {
      filteredProjects = filteredProjects.filter(project => project.category === category)
    }

    if (stage && stage !== 'all') {
      filteredProjects = filteredProjects.filter(project => project.stage === stage)
    }

    if (search) {
      filteredProjects = filteredProjects.filter(project =>
        project.title.toLowerCase().includes(search.toLowerCase()) ||
        project.description.toLowerCase().includes(search.toLowerCase())
      )
    }

    // Sort projects
    filteredProjects.sort((a, b) => {
      switch (sortBy) {
        case 'ai-score':
          return (b.aiScore || 0) - (a.aiScore || 0)
        case 'funding-progress':
          return (b.currentFunding / b.fundingGoal) - (a.currentFunding / a.fundingGoal)
        case 'newest':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        case 'valuation':
          return (b.valuation || 0) - (a.valuation || 0)
        default:
          return 0
      }
    })

    return NextResponse.json({
      success: true,
      data: filteredProjects,
      total: filteredProjects.length
    })
  } catch (error) {
    console.error('Error fetching projects:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch projects' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, description, category, stage, fundingGoal, minInvestment, maxInvestment, equity, entrepreneurId } = body

    if (!title || !description || !category || !stage || !fundingGoal || !minInvestment) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Generate AI score and recommendations using ZAI
    let aiScore = 75 // Default score
    let aiReasons = ['New project submitted']

    try {
      const zai = await ZAI.create()
      
      const prompt = `
        Analyze this investment project and provide:
        1. A score from 0-100 for investment potential
        2. 3-5 key reasons for the score
        
        Project Details:
        Title: ${title}
        Description: ${description}
        Category: ${category}
        Stage: ${stage}
        Funding Goal: $${fundingGoal}
        Min Investment: $${minInvestment}
        ${equity ? `Equity Offered: ${equity}%` : ''}
        
        Consider factors like market potential, team experience, innovation, scalability, and risk.
        Respond in JSON format: {"score": number, "reasons": ["reason1", "reason2", "reason3"]}
      `

      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert investment analyst. Provide objective, data-driven analysis of investment opportunities.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.3,
        max_tokens: 500
      })

      const aiResponse = completion.choices[0]?.message?.content
      if (aiResponse) {
        try {
          const parsed = JSON.parse(aiResponse)
          aiScore = Math.min(100, Math.max(0, parsed.score || 75))
          aiReasons = parsed.reasons || ['Project analyzed by AI']
        } catch (parseError) {
          console.error('Failed to parse AI response:', parseError)
        }
      }
    } catch (aiError) {
      console.error('AI analysis failed:', aiError)
      // Continue with default values
    }

    // Create new project
    const newProject = {
      id: Date.now().toString(),
      title,
      description,
      category,
      stage,
      fundingGoal: parseFloat(fundingGoal),
      currentFunding: 0,
      minInvestment: parseFloat(minInvestment),
      maxInvestment: maxInvestment ? parseFloat(maxInvestment) : undefined,
      equity: equity ? parseFloat(equity) : undefined,
      valuation: equity && fundingGoal ? (fundingGoal / equity) * 100 : undefined,
      status: 'pending',
      entrepreneurId,
      createdAt: new Date().toISOString().split('T')[0],
      views: 0,
      investors: 0,
      aiScore,
      aiReasons
    }

    return NextResponse.json({
      success: true,
      data: newProject,
      message: 'Project submitted successfully. AI analysis completed.'
    })
  } catch (error) {
    console.error('Error creating project:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create project' },
      { status: 500 }
    )
  }
}