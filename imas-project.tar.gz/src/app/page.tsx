'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { Switch } from '@/components/ui/switch'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { 
  TrendingUp, 
  Users, 
  Target, 
  Shield, 
  Globe, 
  Brain,
  Rocket,
  ArrowRight,
  CheckCircle,
  BarChart3,
  DollarSign,
  Lightbulb,
  Award,
  Building,
  Handshake,
  Zap,
  FileText,
  MessageSquare,
  Clock,
  Star
} from 'lucide-react'

export default function Home() {
  const [activeTab, setActiveTab] = useState('overview')
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [animatedStats, setAnimatedStats] = useState({
    projects: 0,
    investors: 0,
    funding: 0,
    success: 0
  })

  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimatedStats({
        projects: 1247,
        investors: 3842,
        funding: 45.8,
        success: 87
      })
    }, 500)
    return () => clearTimeout(timer)
  }, [])

  const features = [
    {
      icon: <Brain className="h-6 w-6" />,
      title: "AI-Powered Matching",
      description: "Advanced algorithms match investors with suitable projects based on preferences, risk tolerance, and investment history",
      color: "text-purple-600"
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "Secure & Transparent",
      description: "Blockchain-inspired transparency with end-to-end encryption for all communications and transactions",
      color: "text-green-600"
    },
    {
      icon: <Target className="h-6 w-6" />,
      title: "Smart Due Diligence",
      description: "Automated background checks, financial analysis, and risk assessment for all investment opportunities",
      color: "text-blue-600"
    },
    {
      icon: <Globe className="h-6 w-6" />,
      title: "Global Network",
      description: "Connect with entrepreneurs and investors from around the world in a unified platform",
      color: "text-indigo-600"
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "Real-time Analytics",
      description: "Live tracking of investments, project progress, and market trends with interactive dashboards",
      color: "text-yellow-600"
    },
    {
      icon: <MessageSquare className="h-6 w-6" />,
      title: "Secure Communication",
      description: "Encrypted messaging system for direct communication between entrepreneurs and investors",
      color: "text-red-600"
    }
  ]

  const testimonials = [
    {
      name: "Sarah Chen",
      role: "CEO, TechStart Inc.",
      avatar: "SC",
      content: "IMAS helped us secure $2.5M in funding within 3 weeks. The AI matching connected us with perfect investors who understood our vision.",
      rating: 5,
      investment: "$2.5M"
    },
    {
      name: "Michael Rodriguez",
      role: "Angel Investor",
      avatar: "MR",
      content: "The platform's due diligence tools saved me countless hours. I've made 8 investments through IMAS with a 75% success rate.",
      rating: 5,
      investment: "$1.2M"
    },
    {
      name: "Emily Johnson",
      role: "Founder, HealthTech Solutions",
      avatar: "EJ",
      content: "As a first-time entrepreneur, IMAS guided me through the entire funding process. The transparency and support were invaluable.",
      rating: 5,
      investment: "$750K"
    }
  ]

  const stats = [
    { label: "Active Projects", value: animatedStats.projects.toLocaleString(), icon: <Rocket className="h-4 w-4" /> },
    { label: "Verified Investors", value: animatedStats.investors.toLocaleString(), icon: <Users className="h-4 w-4" /> },
    { label: "Total Funding", value: `$${animatedStats.funding}M+`, icon: <DollarSign className="h-4 w-4" /> },
    { label: "Success Rate", value: `${animatedStats.success}%`, icon: <TrendingUp className="h-4 w-4" /> }
  ]

  const categories = [
    { name: "Technology", projects: 342, funding: "$12.3M", icon: "💻" },
    { name: "Healthcare", projects: 218, funding: "$8.7M", icon: "🏥" },
    { name: "Finance", projects: 156, funding: "$15.2M", icon: "💰" },
    { name: "Education", projects: 189, funding: "$5.8M", icon: "📚" },
    { name: "Energy", projects: 98, funding: "$9.4M", icon: "⚡" },
    { name: "Agriculture", projects: 144, funding: "$3.9M", icon: "🌾" }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-slate-900/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold">IMAS</span>
              <Badge variant="secondary" className="text-xs">Investment Management Automation System</Badge>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" asChild>
                <a href="/entrepreneur">For Entrepreneurs</a>
              </Button>
              <Button variant="ghost" asChild>
                <a href="/investor">For Investors</a>
              </Button>
              <Button variant="ghost">How It Works</Button>
              <Button variant="ghost">Success Stories</Button>
              <div className="flex items-center space-x-2">
                <Switch 
                  checked={isDarkMode}
                  onCheckedChange={setIsDarkMode}
                />
                <span className="text-sm">Dark</span>
              </div>
              <Button>Get Started</Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <Badge className="mb-4 bg-gradient-to-r from-blue-600 to-purple-600">
            🚀 Democratizing Investment Access
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-slate-900 to-slate-600 dark:from-white dark:to-slate-300 bg-clip-text text-transparent">
            Bridge the Gap Between
            <br />
            Ideas and Investment
          </h1>
          <p className="text-xl text-slate-600 dark:text-slate-400 mb-8 max-w-3xl mx-auto">
            IMAS revolutionizes the investment landscape by connecting entrepreneurs with investors through 
            AI-powered matching, automated due diligence, and secure transaction processing. 
            Transform your innovative ideas into funded reality.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
              Submit Your Project <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline">
              Start Investing
            </Button>
          </div>
          <div className="flex items-center justify-center gap-8 text-sm text-slate-600">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>No Hidden Fees</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>AI-Powered Matching</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Secure Transactions</span>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 px-4 bg-white dark:bg-slate-900">
        <div className="container mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center">
                <CardContent className="pt-6">
                  <div className="flex justify-center mb-2 text-slate-600">
                    {stat.icon}
                  </div>
                  <div className="text-2xl font-bold mb-1">{stat.value}</div>
                  <div className="text-sm text-slate-600">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="features">Features</TabsTrigger>
              <TabsTrigger value="categories">Categories</TabsTrigger>
              <TabsTrigger value="testimonials">Success Stories</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-8">
              <div className="grid md:grid-cols-2 gap-8">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Lightbulb className="h-5 w-5" />
                      The IMAS Advantage
                    </CardTitle>
                    <CardDescription>
                      Why choose our platform for your investment journey
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-600 dark:text-slate-400 mb-4">
                      Traditional investment mechanisms are often exclusive, manual, and lack transparency. 
                      IMAS addresses these challenges through automation, AI-driven insights, and a 
                      user-centric approach that benefits both entrepreneurs and investors.
                    </p>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="text-sm">AI-powered project-investor matching</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="text-sm">Automated due diligence and risk assessment</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="text-sm">Secure communication and transaction channels</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="text-sm">Real-time project progress tracking</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5" />
                      Platform Impact
                    </CardTitle>
                    <CardDescription>
                      Measurable results and community growth
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Projects Successfully Funded</span>
                        <span>342</span>
                      </div>
                      <Progress value={72} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Active Investor Network</span>
                        <span>3,842</span>
                      </div>
                      <Progress value={85} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Total Investment Volume</span>
                        <span>$45.8M</span>
                      </div>
                      <Progress value={68} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Entrepreneur Satisfaction</span>
                        <span>94%</span>
                      </div>
                      <Progress value={94} className="h-2" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="features" className="mt-8">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {features.map((feature, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className={`${feature.color} mb-2`}>{feature.icon}</div>
                      <CardTitle>{feature.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-slate-600 dark:text-slate-400">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="categories" className="mt-8">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {categories.map((category, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="text-3xl">{category.icon}</div>
                        <Badge variant="secondary">{category.projects} projects</Badge>
                      </div>
                      <CardTitle>{category.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-slate-600">Total Funding</span>
                        <span className="font-semibold text-green-600">{category.funding}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="testimonials" className="mt-8">
              <div className="grid md:grid-cols-3 gap-6">
                {testimonials.map((testimonial, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={`/avatar-${index}.jpg`} />
                          <AvatarFallback>{testimonial.avatar}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-semibold">{testimonial.name}</div>
                          <div className="text-sm text-slate-600">{testimonial.role}</div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex mb-3">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <p className="text-slate-600 dark:text-slate-400 italic mb-4">
                        "{testimonial.content}"
                      </p>
                      <div className="flex items-center justify-between">
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          {testimonial.investment} Raised
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="container mx-auto text-center text-white">
          <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Investment Journey?</h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of entrepreneurs and investors already using IMAS
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <a href="/entrepreneur">Submit Your Project</a>
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-slate-900" asChild>
              <a href="/investor">Start Investing</a>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 bg-slate-900 text-white">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="h-8 w-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <TrendingUp className="h-5 w-5 text-white" />
                </div>
                <span className="text-xl font-bold">IMAS</span>
              </div>
              <p className="text-slate-400 text-sm">
                Investment Management Automation System - Bridging the gap between innovative ideas and smart investments.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-3">For Entrepreneurs</h3>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-white">Submit Project</a></li>
                <li><a href="#" className="hover:text-white">Success Stories</a></li>
                <li><a href="#" className="hover:text-white">Resources</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-3">For Investors</h3>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-white">Browse Projects</a></li>
                <li><a href="#" className="hover:text-white">Investment Guide</a></li>
                <li><a href="#" className="hover:text-white">Due Diligence</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-3">Company</h3>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-white">About Us</a></li>
                <li><a href="#" className="hover:text-white">How It Works</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
          </div>
          <Separator className="my-8 bg-slate-700" />
          <div className="text-center text-slate-400 text-sm">
            © 2024 IMAS - Investment Management Automation System. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}