import { Server } from 'socket.io';

export const setupSocket = (io: Server) => {
  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    // Join rooms for different features
    socket.on('join-dashboard', () => {
      socket.join('dashboard');
      socket.emit('joined-dashboard', { message: 'Joined dashboard room' });
    });

    socket.on('join-tasks', () => {
      socket.join('tasks');
      socket.emit('joined-tasks', { message: 'Joined tasks room' });
    });

    // Handle task updates
    socket.on('task-update', (data: { taskId: string; status: string; progress: number }) => {
      socket.to('tasks').emit('task-updated', {
        taskId: data.taskId,
        status: data.status,
        progress: data.progress,
        updatedBy: socket.id,
        timestamp: new Date().toISOString()
      });
    });

    socket.on('task-created', (data: { task: any }) => {
      socket.to('tasks').emit('task-created', {
        task: data.task,
        createdBy: socket.id,
        timestamp: new Date().toISOString()
      });
    });

    socket.on('task-deleted', (data: { taskId: string }) => {
      socket.to('tasks').emit('task-deleted', {
        taskId: data.taskId,
        deletedBy: socket.id,
        timestamp: new Date().toISOString()
      });
    });

    // Handle analytics updates
    socket.on('analytics-update', (data: { metric: string; value: number }) => {
      socket.to('dashboard').emit('analytics-updated', {
        metric: data.metric,
        value: data.value,
        updatedBy: socket.id,
        timestamp: new Date().toISOString()
      });
    });

    // Handle real-time notifications
    socket.on('notification', (data: { message: string; type: string }) => {
      io.emit('notification', {
        message: data.message,
        type: data.type,
        from: socket.id,
        timestamp: new Date().toISOString()
      });
    });

    // Handle typing indicators
    socket.on('typing-start', (data: { userId: string; userName: string }) => {
      socket.to('tasks').emit('user-typing', {
        userId: data.userId,
        userName: data.userName,
        isTyping: true
      });
    });

    socket.on('typing-stop', (data: { userId: string }) => {
      socket.to('tasks').emit('user-typing', {
        userId: data.userId,
        isTyping: false
      });
    });

    // Handle messages
    socket.on('message', (msg: { text: string; senderId: string; room?: string }) => {
      const messageData = {
        text: msg.text,
        senderId: msg.senderId || socket.id,
        timestamp: new Date().toISOString(),
      };

      if (msg.room) {
        socket.to(msg.room).emit('message', messageData);
      } else {
        // Echo: broadcast message to all clients except sender
        socket.broadcast.emit('message', messageData);
      }
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
      socket.to('tasks').emit('user-offline', { userId: socket.id });
      socket.to('dashboard').emit('user-offline', { userId: socket.id });
    });

    // Send welcome message
    socket.emit('message', {
      text: 'Welcome to NextApp Real-time Server!',
      senderId: 'system',
      timestamp: new Date().toISOString(),
    });

    // Notify others about new user
    socket.broadcast.emit('user-connected', { 
      userId: socket.id,
      timestamp: new Date().toISOString()
    });
  });
};