'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  Send, 
  Users, 
  MessageSquare, 
  Activity,
  Bell,
  CheckCircle,
  AlertCircle
} from 'lucide-react'
import { io, Socket } from 'socket.io-client'

interface Message {
  id: string
  text: string
  senderId: string
  timestamp: string
}

interface User {
  id: string
  status: 'online' | 'offline'
  joinedAt: string
}

export default function DemoPage() {
  const [socket, setSocket] = useState<Socket | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [messageInput, setMessageInput] = useState('')
  const [connectedUsers, setConnectedUsers] = useState<User[]>([])
  const [isConnected, setIsConnected] = useState(false)
  const [userName] = useState(`User_${Math.random().toString(36).substr(2, 9)}`)

  useEffect(() => {
    const socketInstance = io()
    
    socketInstance.on('connect', () => {
      console.log('Connected to WebSocket server')
      setIsConnected(true)
    })

    socketInstance.on('disconnect', () => {
      console.log('Disconnected from WebSocket server')
      setIsConnected(false)
    })

    socketInstance.on('message', (data: Message) => {
      setMessages(prev => [...prev, data])
    })

    socketInstance.on('user-connected', (data: { userId: string; timestamp: string }) => {
      setConnectedUsers(prev => [
        ...prev.filter(u => u.id !== data.userId),
        { id: data.userId, status: 'online', joinedAt: data.timestamp }
      ])
    })

    socketInstance.on('user-offline', (data: { userId: string }) => {
      setConnectedUsers(prev => 
        prev.map(user => 
          user.id === data.userId 
            ? { ...user, status: 'offline' }
            : user
        )
      )
    })

    socketInstance.on('notification', (data: { message: string; type: string; from: string; timestamp: string }) => {
      // Handle notifications
      console.log('Notification received:', data)
    })

    setSocket(socketInstance)

    return () => {
      socketInstance.disconnect()
    }
  }, [])

  const sendMessage = () => {
    if (messageInput.trim() && socket) {
      const message: Message = {
        id: Date.now().toString(),
        text: messageInput,
        senderId: userName,
        timestamp: new Date().toISOString()
      }
      
      socket.emit('message', message)
      setMessageInput('')
    }
  }

  const sendNotification = (type: string) => {
    if (socket) {
      const messages = {
        success: 'Task completed successfully!',
        warning: 'Warning: System maintenance scheduled',
        error: 'Error: Failed to process request',
        info: 'Info: New feature available'
      }
      
      socket.emit('notification', {
        message: messages[type as keyof typeof messages],
        type: type
      })
    }
  }

  const onlineUsers = connectedUsers.filter(u => u.status === 'online').length

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Real-time WebSocket Demo</h1>
          <p className="text-slate-600 dark:text-slate-400">
            Experience real-time communication and live updates
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Chat Section */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5" />
                    <CardTitle>Live Chat</CardTitle>
                    <Badge variant={isConnected ? "default" : "destructive"}>
                      {isConnected ? "Connected" : "Disconnected"}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-slate-400" />
                    <span className="text-sm text-slate-600">{onlineUsers} online</span>
                  </div>
                </div>
                <CardDescription>
                  Send and receive messages in real-time
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-96 overflow-y-auto border rounded-lg p-4 mb-4 bg-slate-50 dark:bg-slate-800">
                  {messages.length === 0 ? (
                    <div className="text-center text-slate-500 mt-20">
                      <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No messages yet. Start a conversation!</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.senderId === userName ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-xs px-4 py-2 rounded-lg ${
                              message.senderId === userName
                                ? 'bg-blue-600 text-white'
                                : 'bg-white dark:bg-slate-700 border'
                            }`}
                          >
                            <p className="text-sm font-medium mb-1">
                              {message.senderId}
                            </p>
                            <p>{message.text}</p>
                            <p className="text-xs opacity-70 mt-1">
                              {new Date(message.timestamp).toLocaleTimeString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className="flex gap-2">
                  <Input
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    placeholder="Type your message..."
                    onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                  />
                  <Button onClick={sendMessage} disabled={!messageInput.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Side Panel */}
          <div className="space-y-6">
            {/* Connected Users */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  <CardTitle>Connected Users</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {connectedUsers.length === 0 ? (
                    <p className="text-sm text-slate-600">No users connected</p>
                  ) : (
                    connectedUsers.map((user) => (
                      <div key={user.id} className="flex items-center gap-2">
                        <div className={`h-2 w-2 rounded-full ${
                          user.status === 'online' ? 'bg-green-500' : 'bg-slate-400'
                        }`}></div>
                        <span className="text-sm">{user.id}</span>
                        <Badge variant="outline" className="text-xs">
                          {user.status}
                        </Badge>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Notification Tester */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Bell className="h-5 w-5" />
                  <CardTitle>Test Notifications</CardTitle>
                </div>
                <CardDescription>
                  Send test notifications to all connected users
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => sendNotification('success')}
                >
                  <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                  Success Notification
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => sendNotification('warning')}
                >
                  <AlertCircle className="h-4 w-4 mr-2 text-yellow-600" />
                  Warning Notification
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => sendNotification('error')}
                >
                  <AlertCircle className="h-4 w-4 mr-2 text-red-600" />
                  Error Notification
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => sendNotification('info')}
                >
                  <Activity className="h-4 w-4 mr-2 text-blue-600" />
                  Info Notification
                </Button>
              </CardContent>
            </Card>

            {/* Connection Info */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  <CardTitle>Connection Info</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">Status:</span>
                  <Badge variant={isConnected ? "default" : "destructive"}>
                    {isConnected ? "Connected" : "Disconnected"}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">Your ID:</span>
                  <span className="text-sm font-mono">{userName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">Online Users:</span>
                  <span className="text-sm font-medium">{onlineUsers}</span>
                </div>
                <Separator />
                <div className="text-xs text-slate-500">
                  <p>• Messages are broadcast to all connected users</p>
                  <p>• Notifications are sent in real-time</p>
                  <p>• User presence is tracked automatically</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}