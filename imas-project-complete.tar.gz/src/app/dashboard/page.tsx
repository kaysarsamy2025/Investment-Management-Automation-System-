'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { RealtimeNotifications } from '@/components/RealtimeNotifications'
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  DollarSign, 
  ShoppingCart,
  Activity,
  Calendar,
  Download,
  Filter,
  RefreshCw,
  Eye,
  MousePointer,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  MoreHorizontal,
  Shield
} from 'lucide-react'
import { io, Socket } from 'socket.io-client'

export default function Dashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState('7d')
  const [isLoading, setIsLoading] = useState(false)
  const [revenue, setRevenue] = useState(0)
  const [users, setUsers] = useState(0)
  const [orders, setOrders] = useState(0)
  const [conversion, setConversion] = useState(0)
  const [socket, setSocket] = useState<Socket | null>(null)

  useEffect(() => {
    const timer = setTimeout(() => {
      setRevenue(48574)
      setUsers(12847)
      setOrders(3421)
      setConversion(3.2)
    }, 500)
    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    // Initialize socket connection for real-time updates
    const socketInstance = io()
    
    socketInstance.on('connect', () => {
      console.log('Dashboard connected to WebSocket')
      socketInstance.emit('join-dashboard')
    })

    socketInstance.on('analytics-updated', (data: { metric: string; value: number }) => {
      switch (data.metric) {
        case 'revenue':
          setRevenue(data.value)
          break
        case 'users':
          setUsers(data.value)
          break
        case 'orders':
          setOrders(data.value)
          break
        case 'conversion':
          setConversion(data.value)
          break
      }
    })

    setSocket(socketInstance)

    return () => {
      socketInstance.disconnect()
    }
  }, [])

  const handleRefresh = () => {
    setIsLoading(true)
    setTimeout(() => {
      const newRevenue = Math.floor(Math.random() * 10000) + 40000
      const newUsers = Math.floor(Math.random() * 5000) + 10000
      const newOrders = Math.floor(Math.random() * 1000) + 3000
      const newConversion = parseFloat((Math.random() * 2 + 2).toFixed(1))
      
      setRevenue(newRevenue)
      setUsers(newUsers)
      setOrders(newOrders)
      setConversion(newConversion)
      
      // Emit real-time updates
      if (socket) {
        socket.emit('analytics-update', { metric: 'revenue', value: newRevenue })
        socket.emit('analytics-update', { metric: 'users', value: newUsers })
        socket.emit('analytics-update', { metric: 'orders', value: newOrders })
        socket.emit('analytics-update', { metric: 'conversion', value: newConversion })
      }
      
      setIsLoading(false)
    }, 1000)
  }

  const stats = [
    {
      title: "Total Revenue",
      value: `$${revenue.toLocaleString()}`,
      change: "+12.5%",
      trend: "up",
      icon: <DollarSign className="h-4 w-4" />,
      color: "text-green-600"
    },
    {
      title: "Active Users",
      value: users.toLocaleString(),
      change: "+8.2%",
      trend: "up",
      icon: <Users className="h-4 w-4" />,
      color: "text-blue-600"
    },
    {
      title: "Total Orders",
      value: orders.toLocaleString(),
      change: "-2.4%",
      trend: "down",
      icon: <ShoppingCart className="h-4 w-4" />,
      color: "text-purple-600"
    },
    {
      title: "Conversion Rate",
      value: `${conversion}%`,
      change: "+0.8%",
      trend: "up",
      icon: <TrendingUp className="h-4 w-4" />,
      color: "text-orange-600"
    }
  ]

  const recentActivity = [
    {
      id: 1,
      user: "John Doe",
      action: "Completed purchase",
      time: "2 minutes ago",
      avatar: "JD"
    },
    {
      id: 2,
      user: "Sarah Smith",
      action: "Signed up",
      time: "5 minutes ago",
      avatar: "SS"
    },
    {
      id: 3,
      user: "Mike Johnson",
      action: "Updated profile",
      time: "12 minutes ago",
      avatar: "MJ"
    },
    {
      id: 4,
      user: "Emily Davis",
      action: "Left a review",
      time: "25 minutes ago",
      avatar: "ED"
    }
  ]

  const topProducts = [
    { name: "Premium Plan", sales: 342, revenue: "$34,200" },
    { name: "Basic Plan", sales: 256, revenue: "$12,800" },
    { name: "Enterprise Plan", sales: 89, revenue: "$26,700" },
    { name: "Starter Plan", sales: 178, revenue: "$8,900" }
  ]

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-slate-600 dark:text-slate-400">Monitor your business metrics and performance</p>
          </div>
          <div className="flex gap-2">
            <RealtimeNotifications />
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleRefresh}
              disabled={isLoading}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
          </div>
        </div>

        {/* Period Selector */}
        <div className="flex gap-2 mb-6">
          {['24h', '7d', '30d', '90d'].map((period) => (
            <Button
              key={period}
              variant={selectedPeriod === period ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedPeriod(period)}
            >
              {period === '24h' ? 'Last 24 hours' : 
               period === '7d' ? 'Last 7 days' :
               period === '30d' ? 'Last 30 days' : 'Last 90 days'}
            </Button>
          ))}
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <div className={stat.color}>{stat.icon}</div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="flex items-center text-xs text-slate-600">
                  {stat.trend === 'up' ? (
                    <ArrowUpRight className="h-3 w-3 mr-1 text-green-600" />
                  ) : (
                    <ArrowDownRight className="h-3 w-3 mr-1 text-red-600" />
                  )}
                  <span className={stat.trend === 'up' ? 'text-green-600' : 'text-red-600'}>
                    {stat.change}
                  </span>
                  <span className="ml-1">from last period</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Chart */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Revenue Overview</CardTitle>
                  <CardDescription>Monthly revenue for the current year</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80 flex items-center justify-center bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-center">
                      <BarChart3 className="h-12 w-12 mx-auto mb-4 text-slate-400" />
                      <p className="text-slate-600 dark:text-slate-400">
                        Interactive chart visualization would appear here
                      </p>
                      <p className="text-sm text-slate-500 mt-2">
                        Integration with Recharts or similar library
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Latest user actions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivity.map((activity) => (
                      <div key={activity.id} className="flex items-center gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="text-xs">{activity.avatar}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{activity.user}</p>
                          <p className="text-xs text-slate-600">{activity.action}</p>
                        </div>
                        <div className="text-xs text-slate-500">{activity.time}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Top Products */}
            <Card>
              <CardHeader>
                <CardTitle>Top Products</CardTitle>
                <CardDescription>Best performing products this month</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {topProducts.map((product, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-slate-100 dark:bg-slate-800 rounded flex items-center justify-center text-sm font-medium">
                          {index + 1}
                        </div>
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-slate-600">{product.sales} sales</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{product.revenue}</p>
                        <Progress value={(index + 1) * 20} className="w-20 h-2" />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Traffic Sources</CardTitle>
                  <CardDescription>Where your visitors come from</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { source: "Direct", visitors: 3421, percentage: 45 },
                      { source: "Organic Search", visitors: 2156, percentage: 28 },
                      { source: "Social Media", visitors: 1284, percentage: 17 },
                      { source: "Referral", visitors: 762, percentage: 10 }
                    ].map((item, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <MousePointer className="h-4 w-4 text-slate-400" />
                          <span className="text-sm">{item.source}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium">{item.visitors}</span>
                          <Badge variant="secondary">{item.percentage}%</Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>User Engagement</CardTitle>
                  <CardDescription>How users interact with your platform</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { metric: "Page Views", value: "45.2K", change: "+12%" },
                      { metric: "Avg. Session Duration", value: "3m 24s", change: "+8%" },
                      { metric: "Bounce Rate", value: "42%", change: "-5%" },
                      { metric: "Pages per Session", value: "3.2", change: "+15%" }
                    ].map((item, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Eye className="h-4 w-4 text-slate-400" />
                          <span className="text-sm">{item.metric}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium">{item.value}</span>
                          <Badge 
                            variant={item.change.startsWith('+') ? "default" : "destructive"}
                            className="text-xs"
                          >
                            {item.change}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="reports" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Reports</CardTitle>
                <CardDescription>Detailed insights and analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[
                    { title: "Monthly Report", date: "Nov 2024", status: "Ready" },
                    { title: "Q4 Analysis", date: "Oct 2024", status: "Processing" },
                    { title: "Yearly Summary", date: "Jan 2024", status: "Ready" },
                    { title: "User Behavior", date: "Nov 2024", status: "Ready" },
                    { title: "Sales Performance", date: "Nov 2024", status: "Draft" },
                    { title: "Marketing ROI", date: "Oct 2024", status: "Ready" }
                  ].map((report, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-medium">{report.title}</h4>
                          <p className="text-sm text-slate-600">{report.date}</p>
                        </div>
                        <MoreHorizontal className="h-4 w-4 text-slate-400" />
                      </div>
                      <div className="mt-3">
                        <Badge 
                          variant={report.status === 'Ready' ? "default" : 
                                  report.status === 'Processing' ? "secondary" : "outline"}
                        >
                          {report.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="activity" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>System Activity Log</CardTitle>
                <CardDescription>Recent system events and actions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { 
                      event: "Database backup completed", 
                      time: "10 minutes ago", 
                      type: "success",
                      icon: <Activity className="h-4 w-4" />
                    },
                    { 
                      event: "New user registration spike detected", 
                      time: "25 minutes ago", 
                      type: "info",
                      icon: <Users className="h-4 w-4" />
                    },
                    { 
                      event: "Payment processing completed", 
                      time: "1 hour ago", 
                      type: "success",
                      icon: <DollarSign className="h-4 w-4" />
                    },
                    { 
                      event: "System update available", 
                      time: "2 hours ago", 
                      type: "warning",
                      icon: <RefreshCw className="h-4 w-4" />
                    },
                    { 
                      event: "Security scan completed", 
                      time: "3 hours ago", 
                      type: "success",
                      icon: <Shield className="h-4 w-4" />
                    }
                  ].map((activity, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 border rounded-lg">
                      <div className={`p-2 rounded-full ${
                        activity.type === 'success' ? 'bg-green-100 text-green-600' :
                        activity.type === 'warning' ? 'bg-yellow-100 text-yellow-600' :
                        'bg-blue-100 text-blue-600'
                      }`}>
                        {activity.icon}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{activity.event}</p>
                        <p className="text-xs text-slate-600">{activity.time}</p>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {activity.type}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}