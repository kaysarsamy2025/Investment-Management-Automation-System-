import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const priority = searchParams.get('priority')
    const search = searchParams.get('search')

    // For now, return mock data since we haven't set up the database yet
    const mockTasks = [
      {
        id: '1',
        title: 'Design new landing page',
        description: 'Create mockups and wireframes for the new landing page design',
        status: 'in-progress',
        priority: 'high',
        assignee: 'John Doe',
        dueDate: '2024-12-01',
        createdAt: '2024-11-15',
        tags: ['design', 'frontend'],
        progress: 65
      },
      {
        id: '2',
        title: 'Implement user authentication',
        description: 'Add JWT-based authentication system with refresh tokens',
        status: 'todo',
        priority: 'high',
        assignee: 'Sarah Smith',
        dueDate: '2024-11-25',
        createdAt: '2024-11-10',
        tags: ['backend', 'security'],
        progress: 0
      },
      {
        id: '3',
        title: 'Write API documentation',
        description: 'Document all REST API endpoints with examples',
        status: 'completed',
        priority: 'medium',
        assignee: 'Mike Johnson',
        dueDate: '2024-11-20',
        createdAt: '2024-11-05',
        tags: ['documentation'],
        progress: 100
      }
    ]

    let filteredTasks = mockTasks

    if (status && status !== 'all') {
      filteredTasks = filteredTasks.filter(task => task.status === status)
    }

    if (priority && priority !== 'all') {
      filteredTasks = filteredTasks.filter(task => task.priority === priority)
    }

    if (search) {
      filteredTasks = filteredTasks.filter(task => 
        task.title.toLowerCase().includes(search.toLowerCase()) ||
        task.description.toLowerCase().includes(search.toLowerCase())
      )
    }

    return NextResponse.json({
      success: true,
      data: filteredTasks,
      total: filteredTasks.length
    })
  } catch (error) {
    console.error('Error fetching tasks:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch tasks' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, description, status, priority, assignee, dueDate, tags } = body

    if (!title || !assignee) {
      return NextResponse.json(
        { success: false, error: 'Title and assignee are required' },
        { status: 400 }
      )
    }

    // Create new task (mock implementation)
    const newTask = {
      id: Date.now().toString(),
      title,
      description: description || '',
      status: status || 'todo',
      priority: priority || 'medium',
      assignee,
      dueDate: dueDate || '',
      createdAt: new Date().toISOString().split('T')[0],
      tags: tags || [],
      progress: 0
    }

    return NextResponse.json({
      success: true,
      data: newTask,
      message: 'Task created successfully'
    })
  } catch (error) {
    console.error('Error creating task:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create task' },
      { status: 500 }
    )
  }
}