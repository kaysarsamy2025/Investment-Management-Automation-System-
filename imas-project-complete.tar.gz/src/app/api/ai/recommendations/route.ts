import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { investorId, preferences } = body

    if (!investorId) {
      return NextResponse.json(
        { success: false, error: 'Investor ID is required' },
        { status: 400 }
      )
    }

    // Mock investor profile and projects
    const investorProfile = {
      id: investorId,
      preferredCategories: preferences?.categories || ['Technology', 'Healthcare'],
      investmentRange: preferences?.investmentRange || { min: 10000, max: 100000 },
      riskTolerance: preferences?.riskTolerance || 'medium',
      pastInvestments: [
        { category: 'Technology', amount: 50000, outcome: 'success' },
        { category: 'Healthcare', amount: 25000, outcome: 'success' }
      ]
    }

    const availableProjects = [
      {
        id: '1',
        title: 'AI-Powered Healthcare Platform',
        description: 'Revolutionary AI platform for personalized healthcare recommendations',
        category: 'Healthcare',
        stage: 'MVP',
        fundingGoal: 500000,
        currentFunding: 325000,
        minInvestment: 10000,
        maxInvestment: 100000,
        equity: 15,
        valuation: 3333333,
        team: ['Sarah Chen - CEO', 'Dr. Mike Johnson - CTO'],
        market: '$50B healthcare AI market',
        traction: 'MVP with 1000 beta users',
        ip: '3 patents pending'
      },
      {
        id: '2',
        title: 'Sustainable Energy Storage Solution',
        description: 'Next-generation battery technology using sustainable materials',
        category: 'Energy',
        stage: 'Prototype',
        fundingGoal: 750000,
        currentFunding: 180000,
        minInvestment: 25000,
        maxInvestment: 150000,
        equity: 12,
        valuation: 6250000,
        team: ['Michael Rodriguez - CEO', 'Lisa Wang - CTO'],
        market: '$100B energy storage market',
        traction: 'Lab prototype with 3x performance',
        ip: '2 patents granted'
      },
      {
        id: '3',
        title: 'EdTech Virtual Reality Platform',
        description: 'Immersive VR platform for interactive education',
        category: 'Education',
        stage: 'Idea',
        fundingGoal: 300000,
        currentFunding: 0,
        minInvestment: 5000,
        maxInvestment: 50000,
        equity: 10,
        valuation: 3000000,
        team: ['Emily Johnson - CEO', 'David Kim - CTO'],
        market: '$15B EdTech VR market',
        traction: 'Concept validated with schools',
        ip: 'Proprietary VR algorithms'
      }
    ]

    // Generate AI recommendations using ZAI
    const recommendations = []

    try {
      const zai = await ZAI.create()

      for (const project of availableProjects) {
        const prompt = `
          Analyze this investment opportunity for an investor with the following profile:
          
          Investor Profile:
          - Preferred Categories: ${investorProfile.preferredCategories.join(', ')}
          - Investment Range: $${investorProfile.investmentRange.min} - $${investorProfile.investmentRange.max}
          - Risk Tolerance: ${investorProfile.riskTolerance}
          - Past Investments: ${investorProfile.pastInvestments.map(inv => `${inv.category} ($${inv.amount}) - ${inv.outcome}`).join(', ')}
          
          Project Details:
          - Title: ${project.title}
          - Description: ${project.description}
          - Category: ${project.category}
          - Stage: ${project.stage}
          - Funding Goal: $${project.fundingGoal}
          - Min Investment: $${project.minInvestment}
          - Max Investment: $${project.maxInvestment}
          - Equity: ${project.equity}%
          - Valuation: $${project.valuation}
          - Team: ${project.team.join(', ')}
          - Market: ${project.market}
          - Traction: ${project.traction}
          - IP: ${project.ip}
          
          Provide a recommendation score (0-100) and 3-5 specific reasons for the recommendation.
          Consider investor preferences, risk tolerance, and past investment success.
          
          Respond in JSON format: {"score": number, "reasons": ["reason1", "reason2", "reason3"], "riskLevel": "low|medium|high"}
        `

        const completion = await zai.chat.completions.create({
          messages: [
            {
              role: 'system',
              content: 'You are an expert investment advisor providing personalized recommendations. Be objective but consider the investor\'s profile and preferences.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.3,
          max_tokens: 500
        })

        const aiResponse = completion.choices[0]?.message?.content
        let score = 70
        let reasons = ['AI analysis completed']
        let riskLevel = 'medium'

        if (aiResponse) {
          try {
            const parsed = JSON.parse(aiResponse)
            score = Math.min(100, Math.max(0, parsed.score || 70))
            reasons = parsed.reasons || ['AI analysis completed']
            riskLevel = parsed.riskLevel || 'medium'
          } catch (parseError) {
            console.error('Failed to parse AI response:', parseError)
          }
        }

        // Apply additional scoring based on investor preferences
        if (investorProfile.preferredCategories.includes(project.category)) {
          score += 10
        }

        if (project.minInvestment >= investorProfile.investmentRange.min && 
            project.minInvestment <= investorProfile.investmentRange.max) {
          score += 5
        }

        if (investorProfile.pastInvestments.some(inv => inv.category === project.category && inv.outcome === 'success')) {
          score += 8
        }

        recommendations.push({
          ...project,
          aiScore: Math.min(100, score),
          aiReasons: reasons,
          riskLevel,
          matchScore: score,
          recommendationType: score >= 85 ? 'Strong Buy' : score >= 75 ? 'Buy' : score >= 65 ? 'Consider' : 'Avoid'
        })
      }

      // Sort by AI score
      recommendations.sort((a, b) => b.aiScore - a.aiScore)

    } catch (aiError) {
      console.error('AI recommendation failed:', aiError)
      // Fallback to basic recommendations
      availableProjects.forEach(project => {
        let score = 70
        if (investorProfile.preferredCategories.includes(project.category)) {
          score += 15
        }
        recommendations.push({
          ...project,
          aiScore: score,
          aiReasons: ['Basic preference matching'],
          riskLevel: 'medium',
          matchScore: score,
          recommendationType: score >= 80 ? 'Buy' : 'Consider'
        })
      })
    }

    return NextResponse.json({
      success: true,
      data: {
        investorId,
        recommendations: recommendations.slice(0, 10), // Top 10 recommendations
        totalAnalyzed: availableProjects.length,
        generatedAt: new Date().toISOString()
      },
      message: 'AI recommendations generated successfully'
    })

  } catch (error) {
    console.error('Error generating recommendations:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to generate recommendations' },
      { status: 500 }
    )
  }
}